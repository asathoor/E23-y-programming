<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail sender</title>
</head>
<body>
    <h2>Your mail was send</h2>
    <p>We will return with an answer soon</p>

    <?php
        // mail()
    /?>
</body>
</html>